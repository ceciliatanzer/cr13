<?php

/* default/home.html.twig */
class __TwigTemplate_eb0b1dd382e8e3aed83c90802ee4f042cbd258f2d146bdcd759232884256aa90 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/home.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f058208126825450b4bb781defe0296c5086ea295c192443e0db3748a8fe5898 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f058208126825450b4bb781defe0296c5086ea295c192443e0db3748a8fe5898->enter($__internal_f058208126825450b4bb781defe0296c5086ea295c192443e0db3748a8fe5898_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/home.html.twig"));

        $__internal_fd814408e7547ce444e92effb61caaf09c3fb431a6d923deb768eb24f473e13b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fd814408e7547ce444e92effb61caaf09c3fb431a6d923deb768eb24f473e13b->enter($__internal_fd814408e7547ce444e92effb61caaf09c3fb431a6d923deb768eb24f473e13b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/home.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f058208126825450b4bb781defe0296c5086ea295c192443e0db3748a8fe5898->leave($__internal_f058208126825450b4bb781defe0296c5086ea295c192443e0db3748a8fe5898_prof);

        
        $__internal_fd814408e7547ce444e92effb61caaf09c3fb431a6d923deb768eb24f473e13b->leave($__internal_fd814408e7547ce444e92effb61caaf09c3fb431a6d923deb768eb24f473e13b_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_4baff89c95b6ed629f7f09eb608100ebaf25ef4bb310afadfec0023649a41ebc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4baff89c95b6ed629f7f09eb608100ebaf25ef4bb310afadfec0023649a41ebc->enter($__internal_4baff89c95b6ed629f7f09eb608100ebaf25ef4bb310afadfec0023649a41ebc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_d9f6869d77af70cc9d4cfa49ac7cc0c26dd1b09cfb001cd2dd13c636c5386a89 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d9f6869d77af70cc9d4cfa49ac7cc0c26dd1b09cfb001cd2dd13c636c5386a89->enter($__internal_d9f6869d77af70cc9d4cfa49ac7cc0c26dd1b09cfb001cd2dd13c636c5386a89_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<style>
#read{
\tfont-size:15pt;
\tcolor:red;
}
body{
\tfont-family:Courier New;
\tfont-weight: bold;
}
a{
\tcolor:darkred;
}
#row{
\tmargin-bottom:30px;
\tbackgroud-color: lightgrey;
}
#text{
\tborder:1px;
}

</style>

";
        // line 25
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["events"] ?? $this->getContext($context, "events")));
        foreach ($context['_seq'] as $context["_key"] => $context["event"]) {
            // line 26
            echo "    <div class=\"row\" id=\"row\">
        <div class=\"col-md-6\">
            <a href=\"/details/";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "id", array()), "html", null, true);
            echo "\"><img class=\"img-responsive\" src=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "imagelink", array()), "html", null, true);
            echo "\" style=\"max-width:100%\"></a>
        </div>
        <div class=\"col-md-6\" id=\"text\">
            <a href=\"/details/";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "id", array()), "html", null, true);
            echo "\"><h3 style=\"color:darkred;font-weight: bold;\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "name", array()), "html", null, true);
            echo "</h3></a>

            <p>Beginn: ";
            // line 33
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["event"], "eventBegin", array()), "Y-m-d"), "html", null, true);
            echo "</p>

            <p>End: ";
            // line 35
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["event"], "eventEnd", array()), "Y-m-d"), "html", null, true);
            echo "</p>

            <a id=\"read\" href=\"/details/";
            // line 37
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "id", array()), "html", null, true);
            echo "\">read more...</a><br><br>

            <a href=\"/edit/";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "id", array()), "html", null, true);
            echo "\">Edit event</a><br>

            <a href=\"/remove/";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "id", array()), "html", null, true);
            echo "\">Remove</a>
         </div>
    
       </div> 
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['event'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 46
        echo "
";
        
        $__internal_d9f6869d77af70cc9d4cfa49ac7cc0c26dd1b09cfb001cd2dd13c636c5386a89->leave($__internal_d9f6869d77af70cc9d4cfa49ac7cc0c26dd1b09cfb001cd2dd13c636c5386a89_prof);

        
        $__internal_4baff89c95b6ed629f7f09eb608100ebaf25ef4bb310afadfec0023649a41ebc->leave($__internal_4baff89c95b6ed629f7f09eb608100ebaf25ef4bb310afadfec0023649a41ebc_prof);

    }

    public function getTemplateName()
    {
        return "default/home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  127 => 46,  116 => 41,  111 => 39,  106 => 37,  101 => 35,  96 => 33,  89 => 31,  81 => 28,  77 => 26,  73 => 25,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
<style>
#read{
\tfont-size:15pt;
\tcolor:red;
}
body{
\tfont-family:Courier New;
\tfont-weight: bold;
}
a{
\tcolor:darkred;
}
#row{
\tmargin-bottom:30px;
\tbackgroud-color: lightgrey;
}
#text{
\tborder:1px;
}

</style>

{% for event in events %}
    <div class=\"row\" id=\"row\">
        <div class=\"col-md-6\">
            <a href=\"/details/{{event.id}}\"><img class=\"img-responsive\" src=\"{{event.imagelink}}\" style=\"max-width:100%\"></a>
        </div>
        <div class=\"col-md-6\" id=\"text\">
            <a href=\"/details/{{event.id}}\"><h3 style=\"color:darkred;font-weight: bold;\">{{event.name}}</h3></a>

            <p>Beginn: {{event.eventBegin|date('Y-m-d') }}</p>

            <p>End: {{event.eventEnd|date('Y-m-d') }}</p>

            <a id=\"read\" href=\"/details/{{event.id}}\">read more...</a><br><br>

            <a href=\"/edit/{{event.id}}\">Edit event</a><br>

            <a href=\"/remove/{{event.id}}\">Remove</a>
         </div>
    
       </div> 
{% endfor %}

{% endblock %}", "default/home.html.twig", "C:\\xampp\\htdocs\\event_management\\app\\Resources\\views\\default\\home.html.twig");
    }
}
