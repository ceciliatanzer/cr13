<?php

/* @Twig/layout.html.twig */
class __TwigTemplate_c9f78952cac0f06f836bef76a076f48afb0514ecc489dab37a42fd5e69371b77 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_67ad50e74339fd68d2788ac9874c78f396e238b8a8a09e6619a5e6ae6529e9ab = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_67ad50e74339fd68d2788ac9874c78f396e238b8a8a09e6619a5e6ae6529e9ab->enter($__internal_67ad50e74339fd68d2788ac9874c78f396e238b8a8a09e6619a5e6ae6529e9ab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/layout.html.twig"));

        $__internal_7e65a2dced7ffd67592c6c79350518c3c0de5ff8ffbfc682b592d5f093655a4d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7e65a2dced7ffd67592c6c79350518c3c0de5ff8ffbfc682b592d5f093655a4d->enter($__internal_7e65a2dced7ffd67592c6c79350518c3c0de5ff8ffbfc682b592d5f093655a4d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getCharset(), "html", null, true);
        echo "\" />
        <meta name=\"robots\" content=\"noindex,nofollow\" />
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" />
        <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <link rel=\"icon\" type=\"image/png\" href=\"";
        // line 8
        echo twig_include($this->env, $context, "@Twig/images/favicon.png.base64");
        echo "\">
        <style>";
        // line 9
        echo twig_include($this->env, $context, "@Twig/exception.css.twig");
        echo "</style>
        ";
        // line 10
        $this->displayBlock('head', $context, $blocks);
        // line 11
        echo "    </head>
    <body>
        <header>
            <div class=\"container\">
                <h1 class=\"logo\">";
        // line 15
        echo twig_include($this->env, $context, "@Twig/images/symfony-logo.svg");
        echo " Symfony Exception</h1>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/doc\">
                        <span class=\"icon\">";
        // line 19
        echo twig_include($this->env, $context, "@Twig/images/icon-book.svg");
        echo "</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Docs
                    </a>
                </div>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/support\">
                        <span class=\"icon\">";
        // line 26
        echo twig_include($this->env, $context, "@Twig/images/icon-support.svg");
        echo "</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Support
                    </a>
                </div>
            </div>
        </header>

        ";
        // line 33
        $this->displayBlock('body', $context, $blocks);
        // line 34
        echo "        ";
        echo twig_include($this->env, $context, "@Twig/base_js.html.twig");
        echo "
    </body>
</html>
";
        
        $__internal_67ad50e74339fd68d2788ac9874c78f396e238b8a8a09e6619a5e6ae6529e9ab->leave($__internal_67ad50e74339fd68d2788ac9874c78f396e238b8a8a09e6619a5e6ae6529e9ab_prof);

        
        $__internal_7e65a2dced7ffd67592c6c79350518c3c0de5ff8ffbfc682b592d5f093655a4d->leave($__internal_7e65a2dced7ffd67592c6c79350518c3c0de5ff8ffbfc682b592d5f093655a4d_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_ae610440ccc1b3e96f7ef7494fd19fe1c7ce4d236af6fb98fed8c3fbb457bc2d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ae610440ccc1b3e96f7ef7494fd19fe1c7ce4d236af6fb98fed8c3fbb457bc2d->enter($__internal_ae610440ccc1b3e96f7ef7494fd19fe1c7ce4d236af6fb98fed8c3fbb457bc2d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_6994923a3417bdb3a9a561c05727cd1ee026190b5ad33567a19c8f05a2c56e0e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6994923a3417bdb3a9a561c05727cd1ee026190b5ad33567a19c8f05a2c56e0e->enter($__internal_6994923a3417bdb3a9a561c05727cd1ee026190b5ad33567a19c8f05a2c56e0e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_6994923a3417bdb3a9a561c05727cd1ee026190b5ad33567a19c8f05a2c56e0e->leave($__internal_6994923a3417bdb3a9a561c05727cd1ee026190b5ad33567a19c8f05a2c56e0e_prof);

        
        $__internal_ae610440ccc1b3e96f7ef7494fd19fe1c7ce4d236af6fb98fed8c3fbb457bc2d->leave($__internal_ae610440ccc1b3e96f7ef7494fd19fe1c7ce4d236af6fb98fed8c3fbb457bc2d_prof);

    }

    // line 10
    public function block_head($context, array $blocks = array())
    {
        $__internal_dc0e2b03ddf870939738c5c4c2537dd4c5b37836df7966780bad7f78e14f26d5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dc0e2b03ddf870939738c5c4c2537dd4c5b37836df7966780bad7f78e14f26d5->enter($__internal_dc0e2b03ddf870939738c5c4c2537dd4c5b37836df7966780bad7f78e14f26d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_deebb1a9b7beb667d58ebe6c1e60384c44f24b2d1d9e14b02d6699be7beda3c5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_deebb1a9b7beb667d58ebe6c1e60384c44f24b2d1d9e14b02d6699be7beda3c5->enter($__internal_deebb1a9b7beb667d58ebe6c1e60384c44f24b2d1d9e14b02d6699be7beda3c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        
        $__internal_deebb1a9b7beb667d58ebe6c1e60384c44f24b2d1d9e14b02d6699be7beda3c5->leave($__internal_deebb1a9b7beb667d58ebe6c1e60384c44f24b2d1d9e14b02d6699be7beda3c5_prof);

        
        $__internal_dc0e2b03ddf870939738c5c4c2537dd4c5b37836df7966780bad7f78e14f26d5->leave($__internal_dc0e2b03ddf870939738c5c4c2537dd4c5b37836df7966780bad7f78e14f26d5_prof);

    }

    // line 33
    public function block_body($context, array $blocks = array())
    {
        $__internal_191fa9210e9a7e199209f25dc359035884b4065680e6e236487d3ee931b03e4f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_191fa9210e9a7e199209f25dc359035884b4065680e6e236487d3ee931b03e4f->enter($__internal_191fa9210e9a7e199209f25dc359035884b4065680e6e236487d3ee931b03e4f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_86a159ed5c67d77199e6886477331518086d3109010ff72781ed8ee96ab7088d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_86a159ed5c67d77199e6886477331518086d3109010ff72781ed8ee96ab7088d->enter($__internal_86a159ed5c67d77199e6886477331518086d3109010ff72781ed8ee96ab7088d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_86a159ed5c67d77199e6886477331518086d3109010ff72781ed8ee96ab7088d->leave($__internal_86a159ed5c67d77199e6886477331518086d3109010ff72781ed8ee96ab7088d_prof);

        
        $__internal_191fa9210e9a7e199209f25dc359035884b4065680e6e236487d3ee931b03e4f->leave($__internal_191fa9210e9a7e199209f25dc359035884b4065680e6e236487d3ee931b03e4f_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 33,  120 => 10,  103 => 7,  88 => 34,  86 => 33,  76 => 26,  66 => 19,  59 => 15,  53 => 11,  51 => 10,  47 => 9,  43 => 8,  39 => 7,  33 => 4,  28 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"{{ _charset }}\" />
        <meta name=\"robots\" content=\"noindex,nofollow\" />
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" />
        <title>{% block title %}{% endblock %}</title>
        <link rel=\"icon\" type=\"image/png\" href=\"{{ include('@Twig/images/favicon.png.base64') }}\">
        <style>{{ include('@Twig/exception.css.twig') }}</style>
        {% block head %}{% endblock %}
    </head>
    <body>
        <header>
            <div class=\"container\">
                <h1 class=\"logo\">{{ include('@Twig/images/symfony-logo.svg') }} Symfony Exception</h1>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/doc\">
                        <span class=\"icon\">{{ include('@Twig/images/icon-book.svg') }}</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Docs
                    </a>
                </div>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/support\">
                        <span class=\"icon\">{{ include('@Twig/images/icon-support.svg') }}</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Support
                    </a>
                </div>
            </div>
        </header>

        {% block body %}{% endblock %}
        {{ include('@Twig/base_js.html.twig') }}
    </body>
</html>
", "@Twig/layout.html.twig", "C:\\xampp\\htdocs\\event_management\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\layout.html.twig");
    }
}
