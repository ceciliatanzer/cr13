<?php

/* default/edit.html.twig */
class __TwigTemplate_dfb3dcab51faceecfc46b63191793d17cd91aa8a331721b6b7bd9fec8b4ca912 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1cb4c604ec86a994ef7afa7ce7bfe62735a7054af1ce3f159e3a40ec99a3fe95 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1cb4c604ec86a994ef7afa7ce7bfe62735a7054af1ce3f159e3a40ec99a3fe95->enter($__internal_1cb4c604ec86a994ef7afa7ce7bfe62735a7054af1ce3f159e3a40ec99a3fe95_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/edit.html.twig"));

        $__internal_8c0605547f1ba46382b6dd5d063cb4ba9e31f9158e198cb57104244957b92857 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8c0605547f1ba46382b6dd5d063cb4ba9e31f9158e198cb57104244957b92857->enter($__internal_8c0605547f1ba46382b6dd5d063cb4ba9e31f9158e198cb57104244957b92857_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1cb4c604ec86a994ef7afa7ce7bfe62735a7054af1ce3f159e3a40ec99a3fe95->leave($__internal_1cb4c604ec86a994ef7afa7ce7bfe62735a7054af1ce3f159e3a40ec99a3fe95_prof);

        
        $__internal_8c0605547f1ba46382b6dd5d063cb4ba9e31f9158e198cb57104244957b92857->leave($__internal_8c0605547f1ba46382b6dd5d063cb4ba9e31f9158e198cb57104244957b92857_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_8f6262aac850c1e6348cac57a2926b935ce0fba49bb53aff3083b52261dd3235 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8f6262aac850c1e6348cac57a2926b935ce0fba49bb53aff3083b52261dd3235->enter($__internal_8f6262aac850c1e6348cac57a2926b935ce0fba49bb53aff3083b52261dd3235_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_72801a0cbc298780c84b8c85d7f324f7bb6545caf0cc5be2ac46d25deffbc442 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_72801a0cbc298780c84b8c85d7f324f7bb6545caf0cc5be2ac46d25deffbc442->enter($__internal_72801a0cbc298780c84b8c85d7f324f7bb6545caf0cc5be2ac46d25deffbc442_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<style>

body{
  font-size:15pt;
  font-family:Courier New;
  font-weight: bold;
  color:darkred;
}
form{
  max-width:70%;
}
#button{
  font-size:15pt;
  font-family:Courier New;
  font-weight: bold;
  color:darkred;
}

}

</style>
<form method=\"post\" action=\"";
        // line 24
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("editprocess");
        echo "\">
  <div class=\"form-group\">
    <label for=\"name\">Name:</label>
    <input type=\"text\" class=\"form-control\" name=\"eventName\" value=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "getName", array(), "method"), "html", null, true);
        echo "\">
  </div>

  <div class=\"form-group\">
    <label for=\"telNumber\">Kontakt:</label>
    <input type=\"number\" class=\"form-control\" name=\"telNumber\" value=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "getPhone", array(), "method"), "html", null, true);
        echo "\">
  </div>

  <div class=\"form-group\">
    <label for=\"description\">Description:</label>
    <textarea type=\"text\" class=\"form-control\" name=\"description\" rows=\"5\" cols=\"50\">";
        // line 37
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "getDescription", array(), "method"), "html", null, true);
        echo "</textarea>
  </div>

  <div class=\"form-group\">
    <label for=\"imageLink\">Image Link:</label>
    <input type=\"text\" class=\"form-control\" name=\"imageLink\" value=\"";
        // line 42
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "getImagelink", array(), "method"), "html", null, true);
        echo "\">
  </div>

  <div class=\"form-group\">
    <label for=\"contactPerson\">Person in charge:</label>
    <input type=\"text\" class=\"form-control\" name=\"contactPerson\" value=\"";
        // line 47
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "getContactPerson", array(), "method"), "html", null, true);
        echo "\">
  </div>

  <div class=\"form-group\">
    <label for=\"capacity\">Capacity:</label>
    <input type=\"text\" class=\"form-control\" name=\"capacity\" value=\"";
        // line 52
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "getCapacity", array(), "method"), "html", null, true);
        echo "\">
  </div>

  <div class=\"form-group\">
    <label for=\"address\">Event location:</label>
    <input type=\"text\" class=\"form-control\" name=\"address\" value=\"";
        // line 57
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "getAddress", array(), "method"), "html", null, true);
        echo "\">
  </div>

  <div class=\"form-group\">
    <label for=\"url\">Event url:</label>
    <input type=\"text\" class=\"form-control\" name=\"url\" value=\"";
        // line 62
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "getUrl", array(), "method"), "html", null, true);
        echo "\">
  </div>

  <div class=\"form-group\">
    <label for=\"type\">Event type:</label>
    <input type=\"text\" class=\"form-control\" name=\"type\" value=\"";
        // line 67
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "getType", array(), "method"), "html", null, true);
        echo "\">
  </div>

  <div class=\"form-group\">
    <label for=\"eventBegin\">Event begin date(y-m-d):</label>
    <input type=\"date\" class=\"form-control\" name=\"eventBegin\" value=\"";
        // line 72
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "getEventBegin", array(), "method"), "Y-m-d"), "html", null, true);
        echo "\">
  </div>

  <div class=\"form-group\">
    <label for=\"eventEnd\">Event end date(y-m-d):</label>
    <input type=\"date\" class=\"form-control\" name=\"eventEnd\" value=\"";
        // line 77
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "getEventEnd", array(), "method"), "Y-m-d"), "html", null, true);
        echo "\">
  </div>

  <input type=\"hidden\" name=\"idEvent\" value=\"";
        // line 80
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "getId", array(), "method"), "html", null, true);
        echo "\">

  



  <button id=\"button\" type=\"submit\" class=\"btn btn-default btn-lg btn-block\">Submit</button>
</form>








";
        
        $__internal_72801a0cbc298780c84b8c85d7f324f7bb6545caf0cc5be2ac46d25deffbc442->leave($__internal_72801a0cbc298780c84b8c85d7f324f7bb6545caf0cc5be2ac46d25deffbc442_prof);

        
        $__internal_8f6262aac850c1e6348cac57a2926b935ce0fba49bb53aff3083b52261dd3235->leave($__internal_8f6262aac850c1e6348cac57a2926b935ce0fba49bb53aff3083b52261dd3235_prof);

    }

    public function getTemplateName()
    {
        return "default/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  164 => 80,  158 => 77,  150 => 72,  142 => 67,  134 => 62,  126 => 57,  118 => 52,  110 => 47,  102 => 42,  94 => 37,  86 => 32,  78 => 27,  72 => 24,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
<style>

body{
  font-size:15pt;
  font-family:Courier New;
  font-weight: bold;
  color:darkred;
}
form{
  max-width:70%;
}
#button{
  font-size:15pt;
  font-family:Courier New;
  font-weight: bold;
  color:darkred;
}

}

</style>
<form method=\"post\" action=\"{{path('editprocess')}}\">
  <div class=\"form-group\">
    <label for=\"name\">Name:</label>
    <input type=\"text\" class=\"form-control\" name=\"eventName\" value=\"{{events.getName()}}\">
  </div>

  <div class=\"form-group\">
    <label for=\"telNumber\">Kontakt:</label>
    <input type=\"number\" class=\"form-control\" name=\"telNumber\" value=\"{{events.getPhone()}}\">
  </div>

  <div class=\"form-group\">
    <label for=\"description\">Description:</label>
    <textarea type=\"text\" class=\"form-control\" name=\"description\" rows=\"5\" cols=\"50\">{{events.getDescription()}}</textarea>
  </div>

  <div class=\"form-group\">
    <label for=\"imageLink\">Image Link:</label>
    <input type=\"text\" class=\"form-control\" name=\"imageLink\" value=\"{{events.getImagelink()}}\">
  </div>

  <div class=\"form-group\">
    <label for=\"contactPerson\">Person in charge:</label>
    <input type=\"text\" class=\"form-control\" name=\"contactPerson\" value=\"{{events.getContactPerson()}}\">
  </div>

  <div class=\"form-group\">
    <label for=\"capacity\">Capacity:</label>
    <input type=\"text\" class=\"form-control\" name=\"capacity\" value=\"{{events.getCapacity()}}\">
  </div>

  <div class=\"form-group\">
    <label for=\"address\">Event location:</label>
    <input type=\"text\" class=\"form-control\" name=\"address\" value=\"{{events.getAddress()}}\">
  </div>

  <div class=\"form-group\">
    <label for=\"url\">Event url:</label>
    <input type=\"text\" class=\"form-control\" name=\"url\" value=\"{{events.getUrl()}}\">
  </div>

  <div class=\"form-group\">
    <label for=\"type\">Event type:</label>
    <input type=\"text\" class=\"form-control\" name=\"type\" value=\"{{events.getType()}}\">
  </div>

  <div class=\"form-group\">
    <label for=\"eventBegin\">Event begin date(y-m-d):</label>
    <input type=\"date\" class=\"form-control\" name=\"eventBegin\" value=\"{{events.getEventBegin()|date('Y-m-d')}}\">
  </div>

  <div class=\"form-group\">
    <label for=\"eventEnd\">Event end date(y-m-d):</label>
    <input type=\"date\" class=\"form-control\" name=\"eventEnd\" value=\"{{events.getEventEnd()|date('Y-m-d')}}\">
  </div>

  <input type=\"hidden\" name=\"idEvent\" value=\"{{events.getId()}}\">

  



  <button id=\"button\" type=\"submit\" class=\"btn btn-default btn-lg btn-block\">Submit</button>
</form>








{% endblock %}", "default/edit.html.twig", "C:\\xampp\\htdocs\\event_management\\app\\Resources\\views\\default\\edit.html.twig");
    }
}
