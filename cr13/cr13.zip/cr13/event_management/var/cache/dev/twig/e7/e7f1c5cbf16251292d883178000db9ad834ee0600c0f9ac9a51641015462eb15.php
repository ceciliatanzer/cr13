<?php

/* default/addEvent.html.twig */
class __TwigTemplate_32df1d2b483f87522e6b01f27c9a2779f6e417974456f599a131063ec8e0014c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/addEvent.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aef2a00d20e5f62f6ae613387da3f3548ca751cf2b17bbdd6fbdcadfd668a1d2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aef2a00d20e5f62f6ae613387da3f3548ca751cf2b17bbdd6fbdcadfd668a1d2->enter($__internal_aef2a00d20e5f62f6ae613387da3f3548ca751cf2b17bbdd6fbdcadfd668a1d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/addEvent.html.twig"));

        $__internal_b1cd62092bb989fb0b7384411676359fc07c3a7198dc2a4a5ef8b1e790cbe6dc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b1cd62092bb989fb0b7384411676359fc07c3a7198dc2a4a5ef8b1e790cbe6dc->enter($__internal_b1cd62092bb989fb0b7384411676359fc07c3a7198dc2a4a5ef8b1e790cbe6dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/addEvent.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_aef2a00d20e5f62f6ae613387da3f3548ca751cf2b17bbdd6fbdcadfd668a1d2->leave($__internal_aef2a00d20e5f62f6ae613387da3f3548ca751cf2b17bbdd6fbdcadfd668a1d2_prof);

        
        $__internal_b1cd62092bb989fb0b7384411676359fc07c3a7198dc2a4a5ef8b1e790cbe6dc->leave($__internal_b1cd62092bb989fb0b7384411676359fc07c3a7198dc2a4a5ef8b1e790cbe6dc_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_ed3eb28dfd44d5133f4c8acf763cd88e929e71733f80da2148a920cc05ec9a58 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ed3eb28dfd44d5133f4c8acf763cd88e929e71733f80da2148a920cc05ec9a58->enter($__internal_ed3eb28dfd44d5133f4c8acf763cd88e929e71733f80da2148a920cc05ec9a58_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_62251c7ed29d9bde9fb9199b7be79e996e1c38b91d425fdb9c6a4e178f0cddc5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_62251c7ed29d9bde9fb9199b7be79e996e1c38b91d425fdb9c6a4e178f0cddc5->enter($__internal_62251c7ed29d9bde9fb9199b7be79e996e1c38b91d425fdb9c6a4e178f0cddc5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<style>

body{
  font-size:15pt;
  font-family:Courier New;
  font-weight: bold;
  color:darkred;
}
form{
  max-width:70%;
}
#button{
  font-size:15pt;
  font-family:Courier New;
  font-weight: bold;
  color:darkred;
}


}

</style>
<form method=\"post\" action=\"";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("addEventProcess");
        echo "\">
  <div class=\"form-group\">
    <label for=\"name\">Name:</label>
    <input type=\"text\" class=\"form-control\" name=\"eventName\">
  </div>

  <div class=\"form-group\">
    <label for=\"telNumber\">Kontakt:</label>
    <input type=\"number\" class=\"form-control\" name=\"telNumber\">
  </div>

  <div class=\"form-group\">
    <label for=\"description\">Description:</label>
    <textarea type=\"text\" class=\"form-control\" name=\"description\" rows=\"5\" cols=\"50\"></textarea>
  </div>

  <div class=\"form-group\">
    <label for=\"imageLink\">Image Link:</label>
    <input type=\"text\" class=\"form-control\" name=\"imageLink\">
  </div>

  <div class=\"form-group\">
    <label for=\"contactPerson\">Person in charge:</label>
    <input type=\"text\" class=\"form-control\" name=\"contactPerson\">
  </div>

  <div class=\"form-group\">
    <label for=\"capacity\">Capacity:</label>
    <input type=\"text\" class=\"form-control\" name=\"capacity\">
  </div>

  <div class=\"form-group\">
    <label for=\"address\">Event location:</label>
    <input type=\"text\" class=\"form-control\" name=\"address\">
  </div>

  <div class=\"form-group\">
    <label for=\"url\">Event url:</label>
    <input type=\"text\" class=\"form-control\" name=\"url\">
  </div>

  <div class=\"form-group\">
    <label for=\"type\">Event type:</label>
    <input type=\"text\" class=\"form-control\" name=\"type\">
  </div>

  <div class=\"form-group\">
    <label for=\"eventBegin\">Event begin date(y-m-d):</label>
    <input type=\"date\" class=\"form-control\" name=\"eventBegin\">
  </div>

  <div class=\"form-group\">
    <label for=\"eventEnd\">Event end date(y-m-d):</label>
    <input type=\"date\" class=\"form-control\" name=\"eventEnd\">
  </div>

  



  <button id=\"button\" type=\"submit\" class=\"btn btn-default btn-lg btn-block\">Submit</button>
</form>








";
        
        $__internal_62251c7ed29d9bde9fb9199b7be79e996e1c38b91d425fdb9c6a4e178f0cddc5->leave($__internal_62251c7ed29d9bde9fb9199b7be79e996e1c38b91d425fdb9c6a4e178f0cddc5_prof);

        
        $__internal_ed3eb28dfd44d5133f4c8acf763cd88e929e71733f80da2148a920cc05ec9a58->leave($__internal_ed3eb28dfd44d5133f4c8acf763cd88e929e71733f80da2148a920cc05ec9a58_prof);

    }

    public function getTemplateName()
    {
        return "default/addEvent.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 25,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
<style>

body{
  font-size:15pt;
  font-family:Courier New;
  font-weight: bold;
  color:darkred;
}
form{
  max-width:70%;
}
#button{
  font-size:15pt;
  font-family:Courier New;
  font-weight: bold;
  color:darkred;
}


}

</style>
<form method=\"post\" action=\"{{path('addEventProcess')}}\">
  <div class=\"form-group\">
    <label for=\"name\">Name:</label>
    <input type=\"text\" class=\"form-control\" name=\"eventName\">
  </div>

  <div class=\"form-group\">
    <label for=\"telNumber\">Kontakt:</label>
    <input type=\"number\" class=\"form-control\" name=\"telNumber\">
  </div>

  <div class=\"form-group\">
    <label for=\"description\">Description:</label>
    <textarea type=\"text\" class=\"form-control\" name=\"description\" rows=\"5\" cols=\"50\"></textarea>
  </div>

  <div class=\"form-group\">
    <label for=\"imageLink\">Image Link:</label>
    <input type=\"text\" class=\"form-control\" name=\"imageLink\">
  </div>

  <div class=\"form-group\">
    <label for=\"contactPerson\">Person in charge:</label>
    <input type=\"text\" class=\"form-control\" name=\"contactPerson\">
  </div>

  <div class=\"form-group\">
    <label for=\"capacity\">Capacity:</label>
    <input type=\"text\" class=\"form-control\" name=\"capacity\">
  </div>

  <div class=\"form-group\">
    <label for=\"address\">Event location:</label>
    <input type=\"text\" class=\"form-control\" name=\"address\">
  </div>

  <div class=\"form-group\">
    <label for=\"url\">Event url:</label>
    <input type=\"text\" class=\"form-control\" name=\"url\">
  </div>

  <div class=\"form-group\">
    <label for=\"type\">Event type:</label>
    <input type=\"text\" class=\"form-control\" name=\"type\">
  </div>

  <div class=\"form-group\">
    <label for=\"eventBegin\">Event begin date(y-m-d):</label>
    <input type=\"date\" class=\"form-control\" name=\"eventBegin\">
  </div>

  <div class=\"form-group\">
    <label for=\"eventEnd\">Event end date(y-m-d):</label>
    <input type=\"date\" class=\"form-control\" name=\"eventEnd\">
  </div>

  



  <button id=\"button\" type=\"submit\" class=\"btn btn-default btn-lg btn-block\">Submit</button>
</form>








{% endblock %}", "default/addEvent.html.twig", "C:\\xampp\\htdocs\\event_management\\app\\Resources\\views\\default\\addEvent.html.twig");
    }
}
