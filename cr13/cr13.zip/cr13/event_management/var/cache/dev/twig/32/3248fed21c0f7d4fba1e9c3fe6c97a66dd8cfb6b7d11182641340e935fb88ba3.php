<?php

/* @Twig/images/chevron-right.svg */
class __TwigTemplate_d78ca2e7cc8d0867ee7780948d43b4dfc06b0de08d42b60419f2a42b2dbe2955 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1b2b6e372a0bd43247d76dc8311b4e26948c25c10ff3531fcdbbf857ac5e881e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1b2b6e372a0bd43247d76dc8311b4e26948c25c10ff3531fcdbbf857ac5e881e->enter($__internal_1b2b6e372a0bd43247d76dc8311b4e26948c25c10ff3531fcdbbf857ac5e881e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        $__internal_45b8c673ca8d5df6873d2ca9bd53f7f32ef189645b2b5dc7a7046369bb0b5141 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_45b8c673ca8d5df6873d2ca9bd53f7f32ef189645b2b5dc7a7046369bb0b5141->enter($__internal_45b8c673ca8d5df6873d2ca9bd53f7f32ef189645b2b5dc7a7046369bb0b5141_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
";
        
        $__internal_1b2b6e372a0bd43247d76dc8311b4e26948c25c10ff3531fcdbbf857ac5e881e->leave($__internal_1b2b6e372a0bd43247d76dc8311b4e26948c25c10ff3531fcdbbf857ac5e881e_prof);

        
        $__internal_45b8c673ca8d5df6873d2ca9bd53f7f32ef189645b2b5dc7a7046369bb0b5141->leave($__internal_45b8c673ca8d5df6873d2ca9bd53f7f32ef189645b2b5dc7a7046369bb0b5141_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/chevron-right.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
", "@Twig/images/chevron-right.svg", "C:\\xampp\\htdocs\\event_management\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\images\\chevron-right.svg");
    }
}
