<?php

/* base.html.twig */
class __TwigTemplate_551c2a089b13ddf4e0ac2282d0eb2712a2ea82e32b4a08ce8ba8a82a0817cbe0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9d08412b41fdf1df4b996f06fab81007179ea36a2baf7f1ab077365170784be0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9d08412b41fdf1df4b996f06fab81007179ea36a2baf7f1ab077365170784be0->enter($__internal_9d08412b41fdf1df4b996f06fab81007179ea36a2baf7f1ab077365170784be0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_69cb5985c34318a8e8f0d42d4acc1921f2bb6f115e131c3fc039e107e0b38863 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_69cb5985c34318a8e8f0d42d4acc1921f2bb6f115e131c3fc039e107e0b38863->enter($__internal_69cb5985c34318a8e8f0d42d4acc1921f2bb6f115e131c3fc039e107e0b38863_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
  <head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
 
    <title>";
        // line 8
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    <!-- Bootstrap core CSS -->
    <link href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" rel=\"stylesheet\">
    ";
        // line 11
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 12
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
  </head>
  <body>
    <nav class=\"navbar navbar-inverse\">
      <div class=\"container\">
        <div class=\"navbar-header\">
          <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#navbar\" aria-expanded=\"false\" aria-controls=\"navbar\">
            <span class=\"sr-only\">Toggle navigation</span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
          </button>
        </div>
        <div id=\"navbar\" class=\"collapse navbar-collapse\">
          <ul class=\"nav navbar-nav\">
            <li><a href=\"/\" style=\"font-size:15pt;\">Home</a></li>
            <li><a href=\"/addEvent\" style=\"font-size:15pt;\">Add Event</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
    <div class=\"container-fluid\">
<div class=\"row\">
<div class=\"col-md-12\">
    ";
        // line 36
        $this->displayBlock('body', $context, $blocks);
        // line 37
        echo "</div>
</div>
     
    </div><!-- /.container -->
";
        // line 41
        $this->displayBlock('javascripts', $context, $blocks);
        // line 42
        echo "  </body>
</html>";
        
        $__internal_9d08412b41fdf1df4b996f06fab81007179ea36a2baf7f1ab077365170784be0->leave($__internal_9d08412b41fdf1df4b996f06fab81007179ea36a2baf7f1ab077365170784be0_prof);

        
        $__internal_69cb5985c34318a8e8f0d42d4acc1921f2bb6f115e131c3fc039e107e0b38863->leave($__internal_69cb5985c34318a8e8f0d42d4acc1921f2bb6f115e131c3fc039e107e0b38863_prof);

    }

    // line 8
    public function block_title($context, array $blocks = array())
    {
        $__internal_e256ac95dd8a7dca8da27588133970efb8bbadbe6ce9c3c4a91a041a5ecafbf3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e256ac95dd8a7dca8da27588133970efb8bbadbe6ce9c3c4a91a041a5ecafbf3->enter($__internal_e256ac95dd8a7dca8da27588133970efb8bbadbe6ce9c3c4a91a041a5ecafbf3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_9f944ee64b0d58eeaf647e161bf176c56482c6d097f5736b9f30333e83994eaa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9f944ee64b0d58eeaf647e161bf176c56482c6d097f5736b9f30333e83994eaa->enter($__internal_9f944ee64b0d58eeaf647e161bf176c56482c6d097f5736b9f30333e83994eaa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_9f944ee64b0d58eeaf647e161bf176c56482c6d097f5736b9f30333e83994eaa->leave($__internal_9f944ee64b0d58eeaf647e161bf176c56482c6d097f5736b9f30333e83994eaa_prof);

        
        $__internal_e256ac95dd8a7dca8da27588133970efb8bbadbe6ce9c3c4a91a041a5ecafbf3->leave($__internal_e256ac95dd8a7dca8da27588133970efb8bbadbe6ce9c3c4a91a041a5ecafbf3_prof);

    }

    // line 11
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_fd1bb91f1ac2b264a2a6e9b2e2e0ab11f817806b2bfa920dc9bcd87e685cfd3e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fd1bb91f1ac2b264a2a6e9b2e2e0ab11f817806b2bfa920dc9bcd87e685cfd3e->enter($__internal_fd1bb91f1ac2b264a2a6e9b2e2e0ab11f817806b2bfa920dc9bcd87e685cfd3e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_346747b73a940ba324a9267a9a71a092578451e89f3f6bede81523df7e06b356 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_346747b73a940ba324a9267a9a71a092578451e89f3f6bede81523df7e06b356->enter($__internal_346747b73a940ba324a9267a9a71a092578451e89f3f6bede81523df7e06b356_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_346747b73a940ba324a9267a9a71a092578451e89f3f6bede81523df7e06b356->leave($__internal_346747b73a940ba324a9267a9a71a092578451e89f3f6bede81523df7e06b356_prof);

        
        $__internal_fd1bb91f1ac2b264a2a6e9b2e2e0ab11f817806b2bfa920dc9bcd87e685cfd3e->leave($__internal_fd1bb91f1ac2b264a2a6e9b2e2e0ab11f817806b2bfa920dc9bcd87e685cfd3e_prof);

    }

    // line 36
    public function block_body($context, array $blocks = array())
    {
        $__internal_8b97d48e599323f551efcdc8a3c65ca65dba215d1a05400bba75618d51d27b0a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8b97d48e599323f551efcdc8a3c65ca65dba215d1a05400bba75618d51d27b0a->enter($__internal_8b97d48e599323f551efcdc8a3c65ca65dba215d1a05400bba75618d51d27b0a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_6421d8c1ce6dbcd698f69a67f8b972795c873550625f4cb0ce69c58b7ff7d0ad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6421d8c1ce6dbcd698f69a67f8b972795c873550625f4cb0ce69c58b7ff7d0ad->enter($__internal_6421d8c1ce6dbcd698f69a67f8b972795c873550625f4cb0ce69c58b7ff7d0ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_6421d8c1ce6dbcd698f69a67f8b972795c873550625f4cb0ce69c58b7ff7d0ad->leave($__internal_6421d8c1ce6dbcd698f69a67f8b972795c873550625f4cb0ce69c58b7ff7d0ad_prof);

        
        $__internal_8b97d48e599323f551efcdc8a3c65ca65dba215d1a05400bba75618d51d27b0a->leave($__internal_8b97d48e599323f551efcdc8a3c65ca65dba215d1a05400bba75618d51d27b0a_prof);

    }

    // line 41
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_8d24ccf061bfae9d83d8fd4305c281fb99bb89d17ea4fe862fdcd39985082250 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8d24ccf061bfae9d83d8fd4305c281fb99bb89d17ea4fe862fdcd39985082250->enter($__internal_8d24ccf061bfae9d83d8fd4305c281fb99bb89d17ea4fe862fdcd39985082250_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_3dbc06d870b2f85b661bbefe6ff432b71409f57cfd511ab8caa3a4d96d549f88 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3dbc06d870b2f85b661bbefe6ff432b71409f57cfd511ab8caa3a4d96d549f88->enter($__internal_3dbc06d870b2f85b661bbefe6ff432b71409f57cfd511ab8caa3a4d96d549f88_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_3dbc06d870b2f85b661bbefe6ff432b71409f57cfd511ab8caa3a4d96d549f88->leave($__internal_3dbc06d870b2f85b661bbefe6ff432b71409f57cfd511ab8caa3a4d96d549f88_prof);

        
        $__internal_8d24ccf061bfae9d83d8fd4305c281fb99bb89d17ea4fe862fdcd39985082250->leave($__internal_8d24ccf061bfae9d83d8fd4305c281fb99bb89d17ea4fe862fdcd39985082250_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  147 => 41,  130 => 36,  113 => 11,  95 => 8,  84 => 42,  82 => 41,  76 => 37,  74 => 36,  46 => 12,  44 => 11,  38 => 8,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"en\">
  <head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
 
    <title>{% block title %}Welcome!{% endblock %}</title>
    <!-- Bootstrap core CSS -->
    <link href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" rel=\"stylesheet\">
    {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
  </head>
  <body>
    <nav class=\"navbar navbar-inverse\">
      <div class=\"container\">
        <div class=\"navbar-header\">
          <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#navbar\" aria-expanded=\"false\" aria-controls=\"navbar\">
            <span class=\"sr-only\">Toggle navigation</span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
          </button>
        </div>
        <div id=\"navbar\" class=\"collapse navbar-collapse\">
          <ul class=\"nav navbar-nav\">
            <li><a href=\"/\" style=\"font-size:15pt;\">Home</a></li>
            <li><a href=\"/addEvent\" style=\"font-size:15pt;\">Add Event</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
    <div class=\"container-fluid\">
<div class=\"row\">
<div class=\"col-md-12\">
    {% block body %}{% endblock %}
</div>
</div>
     
    </div><!-- /.container -->
{% block javascripts %}{% endblock %}
  </body>
</html>", "base.html.twig", "C:\\xampp\\htdocs\\event_management\\app\\Resources\\views\\base.html.twig");
    }
}
