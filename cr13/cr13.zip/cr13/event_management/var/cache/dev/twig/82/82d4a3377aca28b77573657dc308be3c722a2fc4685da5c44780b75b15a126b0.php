<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_c78883b0a794df95bdc741371f79e94d9f33e13589dce19f76379b9c0a0f1d06 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_505273bbf13b0d753caac118a3f23f5f5875fb6cde6f3f1ea5362161adb28b7e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_505273bbf13b0d753caac118a3f23f5f5875fb6cde6f3f1ea5362161adb28b7e->enter($__internal_505273bbf13b0d753caac118a3f23f5f5875fb6cde6f3f1ea5362161adb28b7e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_d60b61c089304d262aa3dc59a77e10724c38329667eee984d12c54ecf6fabed6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d60b61c089304d262aa3dc59a77e10724c38329667eee984d12c54ecf6fabed6->enter($__internal_d60b61c089304d262aa3dc59a77e10724c38329667eee984d12c54ecf6fabed6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_505273bbf13b0d753caac118a3f23f5f5875fb6cde6f3f1ea5362161adb28b7e->leave($__internal_505273bbf13b0d753caac118a3f23f5f5875fb6cde6f3f1ea5362161adb28b7e_prof);

        
        $__internal_d60b61c089304d262aa3dc59a77e10724c38329667eee984d12c54ecf6fabed6->leave($__internal_d60b61c089304d262aa3dc59a77e10724c38329667eee984d12c54ecf6fabed6_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_5c1b1d1c196fd9bf410cd6509fb4abbb97422152b4c19ad34d756402df9c2fd0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5c1b1d1c196fd9bf410cd6509fb4abbb97422152b4c19ad34d756402df9c2fd0->enter($__internal_5c1b1d1c196fd9bf410cd6509fb4abbb97422152b4c19ad34d756402df9c2fd0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_edc16eac58f41377aaa251ec8977f00751f02c93a1d6698a788aa9f5582c2bfb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_edc16eac58f41377aaa251ec8977f00751f02c93a1d6698a788aa9f5582c2bfb->enter($__internal_edc16eac58f41377aaa251ec8977f00751f02c93a1d6698a788aa9f5582c2bfb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_edc16eac58f41377aaa251ec8977f00751f02c93a1d6698a788aa9f5582c2bfb->leave($__internal_edc16eac58f41377aaa251ec8977f00751f02c93a1d6698a788aa9f5582c2bfb_prof);

        
        $__internal_5c1b1d1c196fd9bf410cd6509fb4abbb97422152b4c19ad34d756402df9c2fd0->leave($__internal_5c1b1d1c196fd9bf410cd6509fb4abbb97422152b4c19ad34d756402df9c2fd0_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_e215b676556d198fad29cc19af2a8827a997ffcaee5982bdbf31b02249331958 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e215b676556d198fad29cc19af2a8827a997ffcaee5982bdbf31b02249331958->enter($__internal_e215b676556d198fad29cc19af2a8827a997ffcaee5982bdbf31b02249331958_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_7a69babff2c20dd51f5f94a0267f015a66c5dc80c7d2e6f18728bd9e110cc317 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7a69babff2c20dd51f5f94a0267f015a66c5dc80c7d2e6f18728bd9e110cc317->enter($__internal_7a69babff2c20dd51f5f94a0267f015a66c5dc80c7d2e6f18728bd9e110cc317_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_7a69babff2c20dd51f5f94a0267f015a66c5dc80c7d2e6f18728bd9e110cc317->leave($__internal_7a69babff2c20dd51f5f94a0267f015a66c5dc80c7d2e6f18728bd9e110cc317_prof);

        
        $__internal_e215b676556d198fad29cc19af2a8827a997ffcaee5982bdbf31b02249331958->leave($__internal_e215b676556d198fad29cc19af2a8827a997ffcaee5982bdbf31b02249331958_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_2cedfcf645d90155363020465ddd224d943fb0f1535486b43d83236c3aa11790 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2cedfcf645d90155363020465ddd224d943fb0f1535486b43d83236c3aa11790->enter($__internal_2cedfcf645d90155363020465ddd224d943fb0f1535486b43d83236c3aa11790_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_76301cdafe5fddd7fd453aaea4142c419b4e0b99c670c0615b392aeb0e2295a7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_76301cdafe5fddd7fd453aaea4142c419b4e0b99c670c0615b392aeb0e2295a7->enter($__internal_76301cdafe5fddd7fd453aaea4142c419b4e0b99c670c0615b392aeb0e2295a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_76301cdafe5fddd7fd453aaea4142c419b4e0b99c670c0615b392aeb0e2295a7->leave($__internal_76301cdafe5fddd7fd453aaea4142c419b4e0b99c670c0615b392aeb0e2295a7_prof);

        
        $__internal_2cedfcf645d90155363020465ddd224d943fb0f1535486b43d83236c3aa11790->leave($__internal_2cedfcf645d90155363020465ddd224d943fb0f1535486b43d83236c3aa11790_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\xampp\\htdocs\\event_management\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
