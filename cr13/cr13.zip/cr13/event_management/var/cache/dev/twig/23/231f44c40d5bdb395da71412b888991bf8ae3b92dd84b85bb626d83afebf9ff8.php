<?php

/* default/detail.html.twig */
class __TwigTemplate_be6b1c41b73eb071a05762cf6ca71c2490dfdb679b44ad9492551f0922c03c24 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/detail.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_696ba60a9a09aa30b23e9ca401bb23f41209918170d8c864a5d9144c81f0f1f0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_696ba60a9a09aa30b23e9ca401bb23f41209918170d8c864a5d9144c81f0f1f0->enter($__internal_696ba60a9a09aa30b23e9ca401bb23f41209918170d8c864a5d9144c81f0f1f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/detail.html.twig"));

        $__internal_d816fed8f878bf66baa4c2fc80eb1d00128115a51b333e680b99f404c5519dbc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d816fed8f878bf66baa4c2fc80eb1d00128115a51b333e680b99f404c5519dbc->enter($__internal_d816fed8f878bf66baa4c2fc80eb1d00128115a51b333e680b99f404c5519dbc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/detail.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_696ba60a9a09aa30b23e9ca401bb23f41209918170d8c864a5d9144c81f0f1f0->leave($__internal_696ba60a9a09aa30b23e9ca401bb23f41209918170d8c864a5d9144c81f0f1f0_prof);

        
        $__internal_d816fed8f878bf66baa4c2fc80eb1d00128115a51b333e680b99f404c5519dbc->leave($__internal_d816fed8f878bf66baa4c2fc80eb1d00128115a51b333e680b99f404c5519dbc_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_a5a519d89da07d078d048777cbfd9d01e628bae9dee367f7c6ddc268b2e83b46 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a5a519d89da07d078d048777cbfd9d01e628bae9dee367f7c6ddc268b2e83b46->enter($__internal_a5a519d89da07d078d048777cbfd9d01e628bae9dee367f7c6ddc268b2e83b46_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_7da5b4742ca6973674fbe2e683b7abb3d93dbb37230f7084fdb6e2dbd2b6dc7b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7da5b4742ca6973674fbe2e683b7abb3d93dbb37230f7084fdb6e2dbd2b6dc7b->enter($__internal_7da5b4742ca6973674fbe2e683b7abb3d93dbb37230f7084fdb6e2dbd2b6dc7b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<style>
#read{
\tfont-size:15pt;
\tcolor:red;
}
body{
\tfont-family:Courier New;
\tfont-weight: bold;
}
a{
\tcolor:darkred;
}

</style>

<div class=\"row\">

    \t<div class=\"col-md-8\">
            <h3 style=\"color:darkred;font-weight: bold;\">";
        // line 21
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "getName", array(), "method"), "html", null, true);
        echo "</h3>
            <img class=\"img-responsive\" src=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "getImagelink", array(), "method"), "html", null, true);
        echo "\" style=\"max-width:100%;\">
            
            <p><b>Category: </b> ";
        // line 24
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "getType", array(), "method"), "html", null, true);
        echo "</p>
            <p><b>Description: </b>";
        // line 25
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "getDescription", array(), "method"), "html", null, true);
        echo "</p>
            <p><b>Beginn: </b>";
        // line 26
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "getEventBegin", array(), "method"), "Y-m-d"), "html", null, true);
        echo "</p>
            <p><b>End: </b>";
        // line 27
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "getEventEnd", array(), "method"), "Y-m-d"), "html", null, true);
        echo "</p>
            <p><b>Capacity: </b>";
        // line 28
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "getCapacity", array(), "method"), "html", null, true);
        echo "</p>
            <p><b>Location: </b>";
        // line 29
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "getAddress", array(), "method"), "html", null, true);
        echo "</p>
            <a href=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "getUrl", array(), "method"), "html", null, true);
        echo "\"><p>";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "getUrl", array(), "method"), "html", null, true);
        echo "</p></a>
            <p><b>Kontakt Person: </b>";
        // line 31
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "getContactPerson", array(), "method"), "html", null, true);
        echo "</p>
            <p><b>Tel.Nr: </b>";
        // line 32
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "getPhone", array(), "method"), "html", null, true);
        echo "</p>
        
            <a href=\"";
        // line 34
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("homepage");
        echo "\">back to list</a>
        </div>
\t\t</div>

";
        
        $__internal_7da5b4742ca6973674fbe2e683b7abb3d93dbb37230f7084fdb6e2dbd2b6dc7b->leave($__internal_7da5b4742ca6973674fbe2e683b7abb3d93dbb37230f7084fdb6e2dbd2b6dc7b_prof);

        
        $__internal_a5a519d89da07d078d048777cbfd9d01e628bae9dee367f7c6ddc268b2e83b46->leave($__internal_a5a519d89da07d078d048777cbfd9d01e628bae9dee367f7c6ddc268b2e83b46_prof);

    }

    public function getTemplateName()
    {
        return "default/detail.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 34,  112 => 32,  108 => 31,  102 => 30,  98 => 29,  94 => 28,  90 => 27,  86 => 26,  82 => 25,  78 => 24,  73 => 22,  69 => 21,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
<style>
#read{
\tfont-size:15pt;
\tcolor:red;
}
body{
\tfont-family:Courier New;
\tfont-weight: bold;
}
a{
\tcolor:darkred;
}

</style>

<div class=\"row\">

    \t<div class=\"col-md-8\">
            <h3 style=\"color:darkred;font-weight: bold;\">{{events.getName()}}</h3>
            <img class=\"img-responsive\" src=\"{{events.getImagelink()}}\" style=\"max-width:100%;\">
            
            <p><b>Category: </b> {{events.getType()}}</p>
            <p><b>Description: </b>{{events.getDescription()}}</p>
            <p><b>Beginn: </b>{{events.getEventBegin()|date('Y-m-d')}}</p>
            <p><b>End: </b>{{events.getEventEnd()|date('Y-m-d')}}</p>
            <p><b>Capacity: </b>{{events.getCapacity()}}</p>
            <p><b>Location: </b>{{events.getAddress()}}</p>
            <a href=\"{{events.getUrl()}}\"><p>{{events.getUrl()}}</p></a>
            <p><b>Kontakt Person: </b>{{events.getContactPerson()}}</p>
            <p><b>Tel.Nr: </b>{{events.getPhone()}}</p>
        
            <a href=\"{{path('homepage')}}\">back to list</a>
        </div>
\t\t</div>

{% endblock %}", "default/detail.html.twig", "C:\\xampp\\htdocs\\event_management\\app\\Resources\\views\\default\\detail.html.twig");
    }
}
